# Homepage
This is an attempt of me taking on frontend development to create a sort of digital businesscard.
Take a look at it live [HERE](https://prestor.dev/).

It's a very simple page with some elements of CSS and JS, credits to [Particles.js](https://vincentgarreau.com/particles.js/)
for making a easy and clean background.

I will continue to expand and develop this. 
